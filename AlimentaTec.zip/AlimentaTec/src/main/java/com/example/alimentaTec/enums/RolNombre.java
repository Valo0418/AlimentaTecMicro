package com.example.alimentaTec.enums;

public enum RolNombre {
   NUTRIOLOGO,
   PACIENTE
} 