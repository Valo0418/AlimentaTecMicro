package com.example.alimentaTec.enums;

public enum Intensity {
    low,
    medium,
    high
}
